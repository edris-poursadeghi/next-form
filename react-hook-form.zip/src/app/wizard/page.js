import Wizard from "../../../components/wizard";

const WizardPage = () => {
  return (
    <div>
      <Wizard />
    </div>
  );
};

export default WizardPage;
