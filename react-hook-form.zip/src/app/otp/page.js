import Otp from "../../../components/otp";

const OtpPage = () => {
  return (
    <div>
      <Otp />
    </div>
  );
};

export default OtpPage;
