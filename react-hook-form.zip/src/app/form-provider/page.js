import ProviderForm from "../../../components/provider-form";

const OtpPage = () => {
  return (
    <div>
      <ProviderForm />
    </div>
  );
};

export default OtpPage;
